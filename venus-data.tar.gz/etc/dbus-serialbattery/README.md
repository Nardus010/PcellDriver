# dbus-serialbattery

* See [README](https://github.com/Louisvdw/dbus-serialbattery/blob/master/README.md) on GitHub

* See [Documentation](https://louisvdw.github.io/dbus-serialbattery/) on GitHub Pages
